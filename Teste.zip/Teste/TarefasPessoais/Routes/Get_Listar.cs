using TarefasPessoais.Models;

namespace TarefasPessoais.Routes
{
    public static class Get_Listar
    {
        public static void MapGetRoutes(this WebApplication app)
        {
            app.MapGet("/", () => "Lista de Tarefas Pessoais");

            app.MapGet("/tarefas", () => ListaTarefas.Tarefas);

            app.MapGet("/tarefas/{numero}", (int numero) =>
            {
                var tarefa = ListaTarefas.Tarefas.FirstOrDefault(r => r.NumeroTarefa == numero);
                return tarefa != null ? Results.Ok(tarefa)
                    : Results.NotFound("Tarefa não encontrada.");
            });
        }
    }
}
