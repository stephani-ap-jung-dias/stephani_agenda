using TarefasPessoais.Models;

namespace TarefasPessoais.Routes
{
    public static class Post_Cadastrar
    {
        public static void MapPostRoutes(this WebApplication app)
        {
            app.MapPost("/tarefas", (Tarefa nova) =>
            {
                nova.NumeroTarefa = ListaTarefas.Tarefas.Count + 1;
                ListaTarefas.Tarefas.Add(nova);

                return Results.Created($"/tarefas/{nova.NumeroTarefa}", nova);
            });
        }
    }
}
