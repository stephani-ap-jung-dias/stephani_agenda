using TarefasPessoais.Models;

namespace TarefasPessoais.Routes
{
    public static class Patch_AlterarTarefas
    {
        public static void MapPatchRoutes(this WebApplication app)
        {
            app.MapPatch("/tarefas/{numero}", (int numero, Tarefa atualizada) =>
            {
                var tarefa = ListaTarefas.Tarefas.FirstOrDefault(r => r.NumeroTarefa == numero);

                if (tarefa is null)
                    return Results.NotFound("Tarefa não encontrada.");

                tarefa.Nome = atualizada.Nome;
                tarefa.Status = atualizada.Status;

                return Results.Ok(tarefa);
            });
        }
    }
}
